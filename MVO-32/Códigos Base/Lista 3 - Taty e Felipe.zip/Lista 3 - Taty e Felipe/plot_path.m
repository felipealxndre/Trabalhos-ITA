figure(4)
plot(X_Ex5(:,6),X_Ex5(:,5))
hold all
grid on
xlabel('x [m]')
ylabel('h [m]')
axis equal
